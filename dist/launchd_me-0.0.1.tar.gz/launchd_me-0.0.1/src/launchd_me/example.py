def main():
    print("I am main, feel my pain.")
    # with open("/Users/chrisbillows/Documents/CODE/Non_Github_Repos/package-exp_setuptools/src/package_one_name/templates/template.txt") as file_handle:
    #     content = file_handle.readlines()
    #     print(content)

if __name__ == "__main__":
    main()
